"use strict";
const app_module_1 = require("./app.module");
const platform = platformBrowserDynamic();
platform.bootstrapModule(app_module_1.AppModule);
//# sourceMappingURL=main.js.map